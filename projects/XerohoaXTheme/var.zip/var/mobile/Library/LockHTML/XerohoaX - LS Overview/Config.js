// Configuration Clock //

var TwentyFourHour = true;					//12 of 24 hour time
var ZeroAtMidnight = true;
var ampm = true;
var unit = "f";
var woeid = 12794139;
var ClockHeight = 0;
var Language = "en"; 						//Only English [en], Portuguese [pg], German [ge], French [fr], Spanish [sp], Russian [ru], Finnish [fn], and Danish [dn]